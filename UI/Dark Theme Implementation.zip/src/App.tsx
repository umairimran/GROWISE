import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import LoginSignup from './components/LoginSignup';
import TrackSelection from './components/TrackSelection';
import SkillAssessment from './components/SkillAssessment';
import EvaluationFeedback from './components/EvaluationFeedback';
import AIRoadmap from './components/AIRoadmap';
import TechnologyInfo from './components/TechnologyInfo';
import UserInsights from './components/UserInsights';
import AIEvaluation from './components/AIEvaluation';

export default function App() {
  return (
    <div className="dark min-h-screen bg-[#0d0d0d]">
      <Router>
        <Routes>
          <Route path="/" element={<Navigate to="/login" replace />} />
          <Route path="/login" element={<LoginSignup />} />
          <Route path="/tracks" element={<TrackSelection />} />
          <Route path="/assessment" element={<SkillAssessment />} />
          <Route path="/evaluation" element={<EvaluationFeedback />} />
          <Route path="/roadmap" element={<AIRoadmap />} />
          <Route path="/technology/:id" element={<TechnologyInfo />} />
          <Route path="/insights" element={<UserInsights />} />
          <Route path="/ai-evaluation" element={<AIEvaluation />} />
          <Route path="*" element={<Navigate to="/login" replace />} />
        </Routes>
      </Router>
    </div>
  );
}
