import { useState, useRef, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Brain, Send, BookOpen, Target, CheckCircle2, ArrowLeft, Sparkles } from 'lucide-react';

const techData: Record<string, any> = {
  javascript: {
    title: 'JavaScript Basics',
    overview: 'JavaScript is a versatile programming language that powers interactive web applications. Master the fundamentals including variables, functions, and control flow.',
    goals: [
      'Understand variables, data types, and operators',
      'Write functions and understand scope',
      'Master control flow with conditionals and loops',
      'Work with arrays and objects',
      'Handle errors and debugging'
    ],
    resources: [
      { title: 'MDN JavaScript Guide', type: 'Documentation', duration: 'Self-paced' },
      { title: 'JavaScript Fundamentals', type: 'Interactive Course', duration: '3 weeks' },
      { title: 'ES6+ Features', type: 'Video Series', duration: '5 hours' }
    ]
  }
};

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

const initialMessages: Message[] = [
  {
    id: '1',
    role: 'assistant',
    content: "Hi! I'm your AI learning companion. I'm here to help you master JavaScript. Feel free to ask me anything about variables, functions, data types, or any concept you're struggling with. How can I help you today?",
    timestamp: new Date()
  }
];

export default function TechnologyInfo() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [inputValue, setInputValue] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const tech = techData[id || 'javascript'] || techData.javascript;

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputValue,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');

    // Simulate AI response
    setTimeout(() => {
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: getAIResponse(inputValue),
        timestamp: new Date()
      };
      setMessages(prev => [...prev, aiMessage]);
    }, 1000);
  };

  const getAIResponse = (question: string) => {
    const lowerQuestion = question.toLowerCase();
    
    if (lowerQuestion.includes('variable') || lowerQuestion.includes('var')) {
      return "In JavaScript, you can declare variables using `let`, `const`, or `var`. I recommend using `let` for values that change and `const` for constants. For example:\n\n```javascript\nlet age = 25;\nconst name = 'John';\n```\n\nThe key difference is that `let` allows reassignment while `const` doesn't. Would you like to know more about their scope differences?";
    }
    
    if (lowerQuestion.includes('function')) {
      return "JavaScript functions are reusable blocks of code. Here are the main ways to define them:\n\n```javascript\n// Function declaration\nfunction greet(name) {\n  return `Hello, ${name}!`;\n}\n\n// Arrow function (ES6+)\nconst greet = (name) => `Hello, ${name}!`;\n```\n\nArrow functions are more concise and handle `this` differently. What specific aspect of functions would you like to explore?";
    }
    
    if (lowerQuestion.includes('array')) {
      return "Arrays in JavaScript are ordered collections of data. Here are some essential methods:\n\n```javascript\nconst numbers = [1, 2, 3, 4, 5];\n\n// Transform\nconst doubled = numbers.map(n => n * 2);\n\n// Filter\nconst evens = numbers.filter(n => n % 2 === 0);\n\n// Reduce\nconst sum = numbers.reduce((acc, n) => acc + n, 0);\n```\n\nThese methods are fundamental to functional programming in JS. Want to practice with some exercises?";
    }
    
    return "That's a great question! JavaScript is a powerful language with many features to explore. Could you be more specific about what you'd like to learn? For example, you can ask about variables, functions, arrays, objects, async programming, or any specific concept you're working on.";
  };

  return (
    <div className="min-h-screen bg-[#0d0d0d]">
      {/* Header */}
      <div className="border-b border-gray-800 bg-[#1a1a1a] sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-8 py-4">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate('/roadmap')}
              className="text-gray-400 hover:text-white"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Roadmap
            </Button>
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center">
                <Brain className="w-4 h-4 text-white" />
              </div>
              <h1 className="text-white text-xl">{tech.title}</h1>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 h-[calc(100vh-73px)]">
        {/* Main Content - Left Side */}
        <div className="lg:col-span-2 overflow-y-auto p-8 border-r border-gray-800">
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="bg-[#1a1a1a] mb-6">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="goals">Learning Goals</TabsTrigger>
              <TabsTrigger value="resources">Resources</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              <Card className="bg-[#1a1a1a] border-gray-800 p-6">
                <div className="flex items-center gap-2 mb-4">
                  <BookOpen className="w-5 h-5 text-purple-400" />
                  <h3 className="text-white">About This Module</h3>
                </div>
                <p className="text-gray-300 leading-relaxed">
                  {tech.overview}
                </p>
              </Card>

              <Card className="bg-[#1a1a1a] border-gray-800 p-6">
                <h3 className="text-white mb-4">What You'll Learn</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {tech.goals.slice(0, 4).map((goal: string, index: number) => (
                    <div key={index} className="flex items-start gap-3 p-3 rounded-lg bg-[#0d0d0d]">
                      <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-300 text-sm">{goal}</span>
                    </div>
                  ))}
                </div>
              </Card>

              <Card className="bg-gradient-to-br from-purple-900/20 to-blue-900/20 border-purple-500/30 p-6">
                <h3 className="text-white mb-2">Ready to Start?</h3>
                <p className="text-gray-400 mb-4">
                  Begin your learning journey and track your progress
                </p>
                <Button className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
                  Start Learning
                </Button>
              </Card>
            </TabsContent>

            <TabsContent value="goals" className="space-y-4">
              <Card className="bg-[#1a1a1a] border-gray-800 p-6">
                <div className="flex items-center gap-2 mb-6">
                  <Target className="w-5 h-5 text-purple-400" />
                  <h3 className="text-white">Learning Objectives</h3>
                </div>
                <div className="space-y-4">
                  {tech.goals.map((goal: string, index: number) => (
                    <div key={index} className="flex items-start gap-3 p-4 rounded-lg bg-[#0d0d0d] border border-gray-800">
                      <div className="w-8 h-8 rounded-full bg-purple-600/20 flex items-center justify-center flex-shrink-0">
                        <span className="text-purple-400">{index + 1}</span>
                      </div>
                      <div className="flex-1">
                        <p className="text-gray-300">{goal}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            </TabsContent>

            <TabsContent value="resources" className="space-y-4">
              {tech.resources.map((resource: any, index: number) => (
                <Card key={index} className="bg-[#1a1a1a] border-gray-800 p-6 hover:border-gray-700 transition-colors">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <h4 className="text-white mb-2">{resource.title}</h4>
                      <div className="flex items-center gap-3 text-sm text-gray-400">
                        <Badge className="bg-purple-600/20 text-purple-400">
                          {resource.type}
                        </Badge>
                        <span>⏱️ {resource.duration}</span>
                      </div>
                    </div>
                    <Button size="sm" variant="outline" className="bg-[#0d0d0d] border-gray-700 hover:bg-[#252525] text-white">
                      Open
                    </Button>
                  </div>
                </Card>
              ))}
            </TabsContent>
          </Tabs>
        </div>

        {/* AI Chat Assistant - Right Side */}
        <div className="bg-[#1a1a1a] flex flex-col h-full">
          <div className="p-6 border-b border-gray-800">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="text-white">Your Learning Companion</h3>
                <p className="text-sm text-gray-400">Ask me anything about {tech.title}</p>
              </div>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-3 ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {message.role === 'assistant' && (
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center flex-shrink-0">
                    <Brain className="w-4 h-4 text-white" />
                  </div>
                )}
                <div
                  className={`max-w-[80%] rounded-lg p-4 ${
                    message.role === 'user'
                      ? 'bg-purple-600 text-white'
                      : 'bg-[#0d0d0d] text-gray-300 border border-gray-800'
                  }`}
                >
                  <p className="whitespace-pre-wrap text-sm leading-relaxed">{message.content}</p>
                  <span className="text-xs opacity-50 mt-2 block">
                    {message.timestamp.toLocaleTimeString()}
                  </span>
                </div>
                {message.role === 'user' && (
                  <div className="w-8 h-8 rounded-full bg-gray-700 flex items-center justify-center flex-shrink-0">
                    <span className="text-white text-sm">You</span>
                  </div>
                )}
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          <div className="p-6 border-t border-gray-800">
            <form onSubmit={handleSendMessage} className="flex gap-3">
              <Input
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="Ask about JavaScript..."
                className="flex-1 bg-[#0d0d0d] border-gray-800 text-white placeholder:text-gray-600"
              />
              <Button
                type="submit"
                size="icon"
                className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
              >
                <Send className="w-4 h-4" />
              </Button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
