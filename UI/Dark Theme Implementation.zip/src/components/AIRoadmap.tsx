import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Brain, CheckCircle2, Circle, Lock } from 'lucide-react';

const roadmapNodes = [
  {
    id: 'html',
    title: 'HTML Fundamentals',
    status: 'completed',
    duration: '1 week',
    level: 1
  },
  {
    id: 'css',
    title: 'CSS & Styling',
    status: 'completed',
    duration: '2 weeks',
    level: 1
  },
  {
    id: 'javascript',
    title: 'JavaScript Basics',
    status: 'current',
    duration: '3 weeks',
    level: 2
  },
  {
    id: 'dom',
    title: 'DOM Manipulation',
    status: 'current',
    duration: '1 week',
    level: 2
  },
  {
    id: 'async',
    title: 'Async JavaScript',
    status: 'locked',
    duration: '2 weeks',
    level: 3
  },
  {
    id: 'react',
    title: 'React Fundamentals',
    status: 'locked',
    duration: '4 weeks',
    level: 3
  },
  {
    id: 'react-advanced',
    title: 'Advanced React',
    status: 'locked',
    duration: '3 weeks',
    level: 4
  },
  {
    id: 'state-management',
    title: 'State Management',
    status: 'locked',
    duration: '2 weeks',
    level: 4
  },
  {
    id: 'backend',
    title: 'Backend Development',
    status: 'locked',
    duration: '5 weeks',
    level: 5
  },
  {
    id: 'database',
    title: 'Database Design',
    status: 'locked',
    duration: '3 weeks',
    level: 5
  },
  {
    id: 'api',
    title: 'API Development',
    status: 'locked',
    duration: '3 weeks',
    level: 6
  },
  {
    id: 'deployment',
    title: 'Deployment & DevOps',
    status: 'locked',
    duration: '2 weeks',
    level: 6
  }
];

export default function AIRoadmap() {
  const navigate = useNavigate();
  const [selectedNode, setSelectedNode] = useState(roadmapNodes[2]); // JavaScript node

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="w-5 h-5 text-green-500" />;
      case 'current':
        return <Circle className="w-5 h-5 text-purple-500 fill-purple-500" />;
      case 'locked':
        return <Lock className="w-5 h-5 text-gray-600" />;
      default:
        return <Circle className="w-5 h-5 text-gray-600" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'border-green-500 bg-green-900/20';
      case 'current':
        return 'border-purple-500 bg-purple-900/20';
      case 'locked':
        return 'border-gray-700 bg-gray-900/20';
      default:
        return 'border-gray-700';
    }
  };

  const levels = Array.from(new Set(roadmapNodes.map(node => node.level))).sort();

  return (
    <div className="min-h-screen bg-[#0d0d0d] p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center">
              <Brain className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-white text-2xl">Your Learning Roadmap</h1>
          </div>
          <p className="text-gray-400 max-w-2xl mx-auto">
            AI-generated personalized path based on your assessment. Click any node to see details.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Roadmap Flow */}
          <div className="lg:col-span-2">
            <Card className="bg-[#1a1a1a] border-gray-800 p-8">
              <div className="space-y-8">
                {levels.map((level, levelIndex) => (
                  <div key={level}>
                    <div className="flex items-center gap-3 mb-4">
                      <Badge className="bg-gray-800 text-gray-300">
                        Level {level}
                      </Badge>
                      <div className="h-px flex-1 bg-gray-800"></div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {roadmapNodes
                        .filter(node => node.level === level)
                        .map((node, index) => (
                          <div key={node.id} className="relative">
                            <Card
                              className={`p-4 cursor-pointer transition-all hover:scale-105 ${getStatusColor(node.status)} ${
                                selectedNode.id === node.id ? 'ring-2 ring-purple-500' : ''
                              }`}
                              onClick={() => {
                                setSelectedNode(node);
                                if (node.status !== 'locked') {
                                  navigate(`/technology/${node.id}`);
                                }
                              }}
                            >
                              <div className="flex items-start gap-3">
                                {getStatusIcon(node.status)}
                                <div className="flex-1 min-w-0">
                                  <h4 className="text-white mb-1">{node.title}</h4>
                                  <p className="text-sm text-gray-400">{node.duration}</p>
                                </div>
                              </div>
                            </Card>
                            
                            {/* Connection line */}
                            {levelIndex < levels.length - 1 && (
                              <div className="absolute left-1/2 -bottom-6 w-px h-6 bg-gray-700 transform -translate-x-1/2"></div>
                            )}
                          </div>
                        ))}
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Side Panel */}
          <div className="space-y-6">
            <Card className="bg-[#1a1a1a] border-gray-800 p-6">
              <h3 className="text-white mb-4">Selected Module</h3>
              <div className="space-y-4">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    {getStatusIcon(selectedNode.status)}
                    <h4 className="text-white">{selectedNode.title}</h4>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-gray-400">
                    <span>⏱️ {selectedNode.duration}</span>
                    <Badge className="bg-gray-800 text-gray-300">
                      Level {selectedNode.level}
                    </Badge>
                  </div>
                </div>

                <div className="pt-4 border-t border-gray-800">
                  <p className="text-gray-400 text-sm mb-4">
                    {selectedNode.status === 'completed' && 'You have completed this module. Great job!'}
                    {selectedNode.status === 'current' && 'This is your current focus. Click to start learning.'}
                    {selectedNode.status === 'locked' && 'Complete previous modules to unlock this content.'}
                  </p>
                </div>
              </div>
            </Card>

            <Card className="bg-gradient-to-br from-purple-900/20 to-blue-900/20 border-purple-500/30 p-6">
              <h3 className="text-white mb-2">Progress Overview</h3>
              <p className="text-gray-400 text-sm mb-4">
                You've completed 2 out of 12 modules
              </p>
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-400">Completed</span>
                  <span className="text-green-400">2 modules</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-400">In Progress</span>
                  <span className="text-purple-400">2 modules</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-400">Remaining</span>
                  <span className="text-gray-400">8 modules</span>
                </div>
              </div>
            </Card>

            <Card className="bg-[#1a1a1a] border-gray-800 p-6">
              <h3 className="text-white mb-2">Estimated Timeline</h3>
              <p className="text-gray-400 text-sm mb-4">
                Based on 10 hours per week
              </p>
              <div className="text-3xl bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent mb-1">
                28 weeks
              </div>
              <p className="text-sm text-gray-500">≈ 7 months</p>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
