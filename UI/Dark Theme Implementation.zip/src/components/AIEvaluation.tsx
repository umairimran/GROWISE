import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Brain, Send, User, AlertCircle, Lightbulb, Code2 } from 'lucide-react';

interface Message {
  id: string;
  role: 'ai' | 'user';
  content: string;
  timestamp: Date;
  isProject?: boolean;
}

type EvaluationPhase = 'intro' | 'warmup' | 'project' | 'complete';

const warmupQuestions = [
  "Let's start with something fundamental. Can you explain the difference between synchronous and asynchronous programming in JavaScript? When would you use each approach?",
  "That's a good explanation. Now, imagine you're building an e-commerce application and the product listing page is loading very slowly. Walk me through your debugging process and the optimization strategies you would consider."
];

const projectScenarios = [
  {
    title: "Social Media Analytics Dashboard",
    description: `I'd like you to design and architect a **Real-Time Social Media Analytics Dashboard** for a marketing agency.

**Requirements:**
• Track mentions, sentiment, and engagement across Twitter, Instagram, and LinkedIn
• Real-time data updates (new mentions appear within 30 seconds)
• Handle 50,000+ mentions per day
• Users can filter by date range, platform, sentiment, and hashtags
• Generate downloadable reports (PDF/Excel)
• Support 100+ concurrent users
• Must be cost-effective for a mid-sized agency

**Constraints:**
• 6-week development timeline
• Team of 3 developers (you're the lead)
• Budget: $50k for infrastructure/year
• Must be production-ready with monitoring

Take your time to think through this. When you're ready, tell me: **What would be your overall technical approach and architecture?**`,
    followUpQuestions: [
      {
        trigger: 'architecture',
        question: "Interesting architecture choice. Let's dive deeper into the real-time aspect. How specifically would you implement the real-time data pipeline? Walk me through how data flows from social media APIs to the user's browser, and what happens when the API rate limits are hit?"
      },
      {
        trigger: 'database',
        question: "Good thinking on the data layer. Now, let's talk about scalability. Six months from now, the client wants to add 10 more social platforms and track 500K mentions/day. What parts of your architecture would need to change? What would you design differently from day one to prepare for this?"
      },
      {
        trigger: 'frontend',
        question: "I like your frontend approach. Let's discuss performance. With potentially thousands of mentions updating in real-time, how would you prevent the UI from becoming sluggish? What specific optimization techniques would you implement?"
      },
      {
        trigger: 'testing',
        question: "Now let's talk about reliability. How would you test this system, especially the real-time components? What's your strategy for ensuring data accuracy when dealing with multiple third-party APIs?"
      },
      {
        trigger: 'deployment',
        question: "Final question: It's launch day and suddenly you're getting 10x the expected traffic. The dashboard is slow and some users report missing data. Walk me through your incident response process. What do you check first? How do you communicate with stakeholders?"
      }
    ]
  },
  {
    title: "Healthcare Appointment System",
    description: `Design a **Healthcare Appointment Booking and Management System** for a network of 50 clinics.

**Requirements:**
• Patients can book/cancel appointments online
• Support for multiple appointment types (consultation, lab tests, follow-ups)
• Doctors can set their availability and block time slots
• Automated reminders via SMS/Email 24 hours before appointment
• Handle recurring appointments (weekly physical therapy, etc.)
• HIPAA compliant - patient data must be encrypted
• Admin dashboard for clinic managers
• Integration with existing EMR systems

**Constraints:**
• Must handle 10,000+ appointments/day across all clinics
• 99.9% uptime requirement
• Average response time < 500ms
• Must work on mobile and desktop
• Patient data cannot leave US servers

Tell me: **What would be your technical architecture and key design decisions?**`,
    followUpQuestions: [
      {
        trigger: 'architecture',
        question: "Solid architecture. Let's focus on the booking logic. How would you prevent double-booking scenarios? What happens if two patients try to book the same slot simultaneously? Walk me through your solution at the database and application level."
      },
      {
        trigger: 'security',
        question: "Given the HIPAA compliance requirement, how would you implement security across the entire stack? What specific measures would you take for data encryption, access control, and audit logging?"
      },
      {
        trigger: 'notification',
        question: "Let's discuss the reminder system. How would you architect a reliable notification system that sends 10,000+ reminders daily? What happens if a third-party SMS service goes down? How do you ensure reminders are sent exactly 24 hours before?"
      },
      {
        trigger: 'integration',
        question: "Regarding EMR integration, different clinics use different EMR systems. How would you design your integration layer to be flexible? What patterns would you use to handle different APIs and data formats?"
      },
      {
        trigger: 'scaling',
        question: "The clinic network wants to expand to 200 clinics next year. What bottlenecks do you anticipate in your current design? How would you prepare the architecture to handle 4x growth?"
      }
    ]
  }
];

export default function AIEvaluation() {
  const navigate = useNavigate();
  const [phase, setPhase] = useState<EvaluationPhase>('intro');
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'ai',
      content: "Hello! I'm your AI Senior Engineer evaluator. This evaluation is different from typical interviews.\n\nFirst, I'll ask you a couple of warm-up questions to understand your fundamentals. Then, I'll present you with a **real-world project scenario** - and this is where it gets interesting.\n\nYou'll need to design the entire system architecture, make technical decisions, and defend your choices. I'll dive deep into your thinking, challenge your assumptions, and evaluate how you approach complex problems.\n\nThis simulates what it's like to be a tech lead designing a production system. Ready to begin?",
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedProject, setSelectedProject] = useState<number>(0);
  const [projectQuestionIndex, setProjectQuestionIndex] = useState(0);
  const [isStarted, setIsStarted] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const getProgress = () => {
    if (phase === 'warmup') {
      return (currentQuestionIndex / warmupQuestions.length) * 33;
    } else if (phase === 'project') {
      const baseProgress = 33;
      const projectProgress = (projectQuestionIndex / projectScenarios[selectedProject].followUpQuestions.length) * 67;
      return baseProgress + projectProgress;
    }
    return 100;
  };

  const handleStart = () => {
    setIsStarted(true);
    setPhase('warmup');
    
    setTimeout(() => {
      const aiMessage: Message = {
        id: Date.now().toString(),
        role: 'ai',
        content: warmupQuestions[0],
        timestamp: new Date()
      };
      setMessages(prev => [...prev, aiMessage]);
    }, 1000);
  };

  const getProjectFollowUp = (userResponse: string) => {
    const project = projectScenarios[selectedProject];
    const lowerResponse = userResponse.toLowerCase();
    
    // Try to find the most relevant follow-up based on what the user mentioned
    for (const followUp of project.followUpQuestions) {
      if (lowerResponse.includes(followUp.trigger)) {
        return followUp.question;
      }
    }
    
    // Return the next sequential question if no keyword match
    if (projectQuestionIndex < project.followUpQuestions.length) {
      return project.followUpQuestions[projectQuestionIndex].question;
    }
    
    return null;
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim() || !isStarted) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputValue,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');

    // Simulate AI response
    setTimeout(() => {
      let aiResponse = '';
      let isProjectMessage = false;

      if (phase === 'warmup') {
        if (currentQuestionIndex < warmupQuestions.length - 1) {
          const acknowledgments = [
            "Good answer. ",
            "I see your thinking. ",
            "That makes sense. "
          ];
          aiResponse = acknowledgments[Math.floor(Math.random() * acknowledgments.length)] + warmupQuestions[currentQuestionIndex + 1];
          setCurrentQuestionIndex(currentQuestionIndex + 1);
        } else {
          // Transition to project phase
          setPhase('project');
          setProjectQuestionIndex(0);
          const project = projectScenarios[selectedProject];
          aiResponse = `Excellent. Now, let's move to the main evaluation - a real-world project scenario.\n\n═══════════════════════════════════\n\n**PROJECT: ${project.title}**\n\n${project.description}`;
          isProjectMessage = true;
        }
      } else if (phase === 'project') {
        const followUp = getProjectFollowUp(inputValue);
        
        if (followUp && projectQuestionIndex < projectScenarios[selectedProject].followUpQuestions.length - 1) {
          const acknowledgments = [
            "Interesting approach. ",
            "I see the reasoning behind that. ",
            "That's a solid consideration. ",
            "Good thinking. "
          ];
          aiResponse = acknowledgments[Math.floor(Math.random() * acknowledgments.length)] + followUp;
          setProjectQuestionIndex(projectQuestionIndex + 1);
        } else {
          // Complete evaluation
          setPhase('complete');
          aiResponse = `Outstanding work! You've completed the evaluation.\n\nI'm impressed with your architectural thinking and how you approached the problem. You demonstrated:\n\n✓ Strong system design fundamentals\n✓ Consideration for scalability and performance\n✓ Awareness of real-world constraints\n✓ Practical problem-solving approach\n\nYour evaluation has been recorded and analyzed. You've shown the mindset of a senior engineer who thinks beyond just writing code - you consider the bigger picture, trade-offs, and long-term maintainability.\n\nWould you like to see your detailed performance insights?`;
        }
      }

      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'ai',
        content: aiResponse,
        timestamp: new Date(),
        isProject: isProjectMessage
      };
      setMessages(prev => [...prev, aiMessage]);
    }, 2000);
  };

  const handleViewResults = () => {
    navigate('/insights');
  };

  const getPhaseLabel = () => {
    switch (phase) {
      case 'intro':
        return 'Welcome';
      case 'warmup':
        return 'Warm-up Questions';
      case 'project':
        return 'Project Architecture';
      case 'complete':
        return 'Complete';
      default:
        return '';
    }
  };

  return (
    <div className="min-h-screen bg-[#0d0d0d]">
      {/* Header */}
      <div className="border-b border-gray-800 bg-[#1a1a1a] sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center">
                <Brain className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-white">AI Senior Engineer Evaluation</h1>
                <p className="text-sm text-gray-400">Project-Based Technical Assessment</p>
              </div>
            </div>
            {isStarted && phase !== 'intro' && (
              <Badge className="bg-purple-600/20 text-purple-400">
                {getPhaseLabel()}
              </Badge>
            )}
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-8">
        {/* Progress Bar */}
        {isStarted && phase !== 'intro' && phase !== 'complete' && (
          <Card className="bg-[#1a1a1a] border-gray-800 p-6 mb-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-400">
                {phase === 'warmup' ? 'Warm-up Phase' : 'Project Evaluation'}
              </span>
              <span className="text-sm text-purple-400">{Math.round(getProgress())}% Complete</span>
            </div>
            <Progress value={getProgress()} className="h-2 bg-gray-800" />
            
            {phase === 'project' && (
              <div className="flex items-center gap-2 mt-3 text-sm text-gray-400">
                <Lightbulb className="w-4 h-4 text-yellow-500" />
                <span>Project deep-dive in progress - explain your architectural decisions</span>
              </div>
            )}
          </Card>
        )}

        {/* Info Card */}
        {!isStarted && (
          <Card className="bg-gradient-to-br from-purple-900/20 to-blue-900/20 border-purple-500/30 p-8 mb-6">
            <div className="flex items-start gap-4">
              <AlertCircle className="w-6 h-6 text-purple-400 flex-shrink-0 mt-1" />
              <div>
                <h3 className="text-white mb-2">The Master Evaluation Challenge</h3>
                <p className="text-gray-300 mb-4">
                  This is our unique approach to technical assessment. Unlike traditional coding tests, 
                  you'll be evaluated on how you think, design, and architect real-world systems.
                </p>
                
                <div className="space-y-3 mb-4">
                  <div className="flex items-start gap-3 p-3 rounded-lg bg-[#0d0d0d] border border-gray-800">
                    <div className="w-8 h-8 rounded-lg bg-purple-600/20 flex items-center justify-center flex-shrink-0">
                      <span className="text-purple-400">1</span>
                    </div>
                    <div>
                      <p className="text-white text-sm mb-1">Warm-up Questions</p>
                      <p className="text-gray-400 text-xs">Quick fundamentals check (2 questions)</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3 p-3 rounded-lg bg-[#0d0d0d] border border-purple-500/30">
                    <div className="w-8 h-8 rounded-lg bg-purple-600/20 flex items-center justify-center flex-shrink-0">
                      <Code2 className="w-4 h-4 text-purple-400" />
                    </div>
                    <div>
                      <p className="text-white text-sm mb-1">Real-World Project Challenge</p>
                      <p className="text-gray-400 text-xs">
                        Design a complete system architecture. The AI will probe your decisions, 
                        challenge your assumptions, and evaluate your problem-solving approach.
                      </p>
                    </div>
                  </div>
                </div>

                <ul className="space-y-2 text-sm text-gray-400">
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-purple-400"></div>
                    Think like a senior engineer - consider scalability, costs, and trade-offs
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-purple-400"></div>
                    Be detailed in your explanations - show your thought process
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-purple-400"></div>
                    Expect deep technical discussions and follow-up questions
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-purple-400"></div>
                    Estimated time: 30-45 minutes
                  </li>
                </ul>
              </div>
            </div>
          </Card>
        )}

        {/* Chat Messages */}
        <Card className="bg-[#1a1a1a] border-gray-800 mb-6">
          <div className="p-6 space-y-6 max-h-[60vh] overflow-y-auto">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-4 ${message.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}
              >
                <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                  message.role === 'ai'
                    ? 'bg-gradient-to-br from-purple-600 to-blue-600'
                    : 'bg-gray-700'
                }`}>
                  {message.role === 'ai' ? (
                    <Brain className="w-5 h-5 text-white" />
                  ) : (
                    <User className="w-5 h-5 text-white" />
                  )}
                </div>
                <div
                  className={`flex-1 rounded-lg p-4 ${
                    message.role === 'user'
                      ? 'bg-purple-600/20 border border-purple-500/30'
                      : message.isProject
                      ? 'bg-gradient-to-br from-blue-900/20 to-purple-900/20 border border-blue-500/30'
                      : 'bg-[#0d0d0d] border border-gray-800'
                  }`}
                >
                  <p className="text-gray-300 leading-relaxed whitespace-pre-wrap">
                    {message.content}
                  </p>
                  <span className="text-xs text-gray-500 mt-2 block">
                    {message.timestamp.toLocaleTimeString()}
                  </span>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
        </Card>

        {/* Input Area */}
        {!isStarted ? (
          <div className="flex justify-center">
            <Button
              size="lg"
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
              onClick={handleStart}
            >
              Begin Master Evaluation
            </Button>
          </div>
        ) : phase === 'complete' ? (
          <div className="flex justify-center">
            <Button
              size="lg"
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
              onClick={handleViewResults}
            >
              View Performance Insights
            </Button>
          </div>
        ) : (
          <form onSubmit={handleSendMessage}>
            <Card className="bg-[#1a1a1a] border-gray-800 p-4">
              <Textarea
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder={
                  phase === 'project'
                    ? "Explain your architectural approach in detail... Consider scalability, costs, trade-offs, and implementation strategy."
                    : "Type your answer here... (Press Ctrl+Enter to send)"
                }
                className="min-h-[150px] bg-[#0d0d0d] border-gray-800 text-white resize-none mb-4"
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && e.ctrlKey) {
                    handleSendMessage(e);
                  }
                }}
              />
              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-500">
                  {phase === 'project' 
                    ? "💡 Think architecture, scalability, and real-world constraints"
                    : "💡 Explain your reasoning clearly"
                  }
                </span>
                <Button
                  type="submit"
                  className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                  disabled={!inputValue.trim()}
                >
                  Send Answer
                  <Send className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </Card>
          </form>
        )}
      </div>
    </div>
  );
}
