import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Progress } from './ui/progress';
import { Brain, Code, CheckCircle2 } from 'lucide-react';

const questions = [
  {
    id: 1,
    type: 'mcq',
    question: 'What is the time complexity of binary search?',
    options: [
      'O(n)',
      'O(log n)',
      'O(n²)',
      'O(1)'
    ]
  },
  {
    id: 2,
    type: 'mcq',
    question: 'Which of these is NOT a JavaScript framework?',
    options: [
      'React',
      'Vue',
      'Django',
      'Angular'
    ]
  },
  {
    id: 3,
    type: 'mcq',
    question: 'What does REST stand for in API design?',
    options: [
      'Remote Execution State Transfer',
      'Representational State Transfer',
      'Resource Execution Service Type',
      'Remote Service Transaction'
    ]
  },
  {
    id: 4,
    type: 'code',
    question: 'Write a function that reverses a string without using built-in reverse methods.',
    placeholder: 'function reverseString(str) {\n  // your code here\n}'
  },
  {
    id: 5,
    type: 'mcq',
    question: 'Which data structure uses LIFO (Last In First Out)?',
    options: [
      'Queue',
      'Stack',
      'Array',
      'Tree'
    ]
  },
  {
    id: 6,
    type: 'mcq',
    question: 'What is the purpose of useState hook in React?',
    options: [
      'To make API calls',
      'To manage component state',
      'To handle routing',
      'To style components'
    ]
  },
  {
    id: 7,
    type: 'code',
    question: 'Explain how you would optimize a slow database query. Describe your approach.',
    placeholder: 'Describe your optimization strategy...'
  },
  {
    id: 8,
    type: 'mcq',
    question: 'Which HTTP method is idempotent?',
    options: [
      'POST',
      'GET',
      'PATCH',
      'All of the above'
    ]
  },
  {
    id: 9,
    type: 'mcq',
    question: 'What is the main purpose of async/await in JavaScript?',
    options: [
      'To make code run faster',
      'To handle asynchronous operations',
      'To create classes',
      'To manage memory'
    ]
  },
  {
    id: 10,
    type: 'mcq',
    question: 'Which design pattern is used to create a single instance of a class?',
    options: [
      'Factory',
      'Observer',
      'Singleton',
      'Decorator'
    ]
  }
];

export default function SkillAssessment() {
  const navigate = useNavigate();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<number, string>>({});

  const progress = ((currentQuestion + 1) / questions.length) * 100;
  const question = questions[currentQuestion];

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      navigate('/evaluation');
    }
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  const handleAnswerChange = (value: string) => {
    setAnswers({ ...answers, [question.id]: value });
  };

  return (
    <div className="min-h-screen bg-[#0d0d0d] p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center">
              <Brain className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-white text-2xl">Skill Assessment</h1>
          </div>
          <p className="text-gray-400">
            Help us understand your current level so we can personalize your learning path
          </p>
        </div>

        {/* Progress */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-400">Question {currentQuestion + 1} of {questions.length}</span>
            <span className="text-sm text-purple-400">{Math.round(progress)}% Complete</span>
          </div>
          <Progress value={progress} className="h-2 bg-gray-800" />
        </div>

        {/* Question Card */}
        <Card className="bg-[#1a1a1a] border-gray-800 p-8 mb-6">
          <div className="space-y-6">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-purple-600/20 flex items-center justify-center flex-shrink-0">
                {question.type === 'mcq' ? (
                  <CheckCircle2 className="w-4 h-4 text-purple-400" />
                ) : (
                  <Code className="w-4 h-4 text-purple-400" />
                )}
              </div>
              <div className="flex-1">
                <h3 className="text-white mb-4">{question.question}</h3>

                {question.type === 'mcq' && question.options ? (
                  <RadioGroup
                    value={answers[question.id] || ''}
                    onValueChange={handleAnswerChange}
                    className="space-y-3"
                  >
                    {question.options.map((option, index) => (
                      <div
                        key={index}
                        className="flex items-center space-x-3 p-4 rounded-lg bg-[#0d0d0d] border border-gray-800 hover:border-gray-700 transition-colors cursor-pointer"
                      >
                        <RadioGroupItem value={option} id={`option-${index}`} />
                        <Label
                          htmlFor={`option-${index}`}
                          className="flex-1 text-gray-300 cursor-pointer"
                        >
                          {option}
                        </Label>
                      </div>
                    ))}
                  </RadioGroup>
                ) : (
                  <Textarea
                    value={answers[question.id] || ''}
                    onChange={(e) => handleAnswerChange(e.target.value)}
                    placeholder={question.placeholder}
                    className="min-h-[200px] bg-[#0d0d0d] border-gray-800 text-white font-mono"
                  />
                )}
              </div>
            </div>
          </div>
        </Card>

        {/* Navigation */}
        <div className="flex items-center justify-between">
          <Button
            variant="outline"
            onClick={handlePrevious}
            disabled={currentQuestion === 0}
            className="bg-[#1a1a1a] border-gray-800 hover:bg-[#252525] text-white"
          >
            Previous
          </Button>

          <div className="flex gap-2">
            {questions.map((_, index) => (
              <div
                key={index}
                className={`w-2 h-2 rounded-full transition-colors ${
                  index === currentQuestion
                    ? 'bg-purple-500'
                    : answers[questions[index].id]
                    ? 'bg-green-500'
                    : 'bg-gray-700'
                }`}
              />
            ))}
          </div>

          <Button
            onClick={handleNext}
            className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
          >
            {currentQuestion === questions.length - 1 ? 'Submit Assessment' : 'Next'}
          </Button>
        </div>
      </div>
    </div>
  );
}
