import { useNavigate } from 'react-router-dom';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Brain, Code, Database, Lock, Smartphone, Cloud, Sparkles, TrendingUp } from 'lucide-react';
import { useState } from 'react';

const tracks = [
  {
    id: 'ai-development',
    title: 'AI Application Development',
    description: 'Build intelligent applications using machine learning and LLMs',
    icon: Brain,
    gradient: 'from-purple-600 to-purple-800',
    bgGradient: 'from-purple-900/20 to-purple-950/40'
  },
  {
    id: 'web-development',
    title: 'Full Stack Web Development',
    description: 'Master modern web technologies from frontend to backend',
    icon: Code,
    gradient: 'from-blue-600 to-blue-800',
    bgGradient: 'from-blue-900/20 to-blue-950/40'
  },
  {
    id: 'machine-learning',
    title: 'Machine Learning Engineering',
    description: 'Deep dive into ML algorithms, neural networks, and AI systems',
    icon: Sparkles,
    gradient: 'from-teal-600 to-teal-800',
    bgGradient: 'from-teal-900/20 to-teal-950/40'
  },
  {
    id: 'cybersecurity',
    title: 'Cybersecurity',
    description: 'Learn security principles, ethical hacking, and defense strategies',
    icon: Lock,
    gradient: 'from-red-600 to-red-800',
    bgGradient: 'from-red-900/20 to-red-950/40'
  },
  {
    id: 'mobile-development',
    title: 'Mobile App Development',
    description: 'Create cross-platform mobile apps for iOS and Android',
    icon: Smartphone,
    gradient: 'from-green-600 to-green-800',
    bgGradient: 'from-green-900/20 to-green-950/40'
  },
  {
    id: 'cloud-architecture',
    title: 'Cloud Architecture',
    description: 'Design and deploy scalable cloud infrastructure and services',
    icon: Cloud,
    gradient: 'from-orange-600 to-orange-800',
    bgGradient: 'from-orange-900/20 to-orange-950/40'
  },
  {
    id: 'data-science',
    title: 'Data Science & Analytics',
    description: 'Extract insights from data using statistics and visualization',
    icon: TrendingUp,
    gradient: 'from-indigo-600 to-indigo-800',
    bgGradient: 'from-indigo-900/20 to-indigo-950/40'
  },
  {
    id: 'database-engineering',
    title: 'Database Engineering',
    description: 'Master SQL, NoSQL, and distributed database systems',
    icon: Database,
    gradient: 'from-yellow-600 to-yellow-800',
    bgGradient: 'from-yellow-900/20 to-yellow-950/40'
  }
];

export default function TrackSelection() {
  const navigate = useNavigate();
  const [selectedTrack, setSelectedTrack] = useState<string | null>(null);

  const handleContinue = () => {
    if (selectedTrack) {
      navigate('/assessment');
    }
  };

  return (
    <div className="min-h-screen bg-[#0d0d0d] p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center">
              <Brain className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-white text-2xl">AI Learn</h1>
          </div>
          <h2 className="text-white mb-3">Choose Your Learning Path</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Select a track that aligns with your career goals. Our AI will personalize your curriculum based on your current skills.
          </p>
        </div>

        {/* Track Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-8">
          {tracks.map((track) => {
            const Icon = track.icon;
            const isSelected = selectedTrack === track.id;
            
            return (
              <Card
                key={track.id}
                className={`group relative overflow-hidden cursor-pointer transition-all duration-300 bg-[#1a1a1a] border-2 hover:border-gray-700 ${
                  isSelected ? 'border-purple-500 ring-2 ring-purple-500/50' : 'border-gray-800'
                }`}
                onClick={() => setSelectedTrack(track.id)}
              >
                <div className={`absolute inset-0 bg-gradient-to-br ${track.bgGradient} opacity-0 group-hover:opacity-100 transition-opacity duration-300`}></div>
                
                <div className="relative p-6 space-y-4">
                  <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${track.gradient} flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  
                  <div>
                    <h3 className="text-white mb-2">{track.title}</h3>
                    <p className="text-gray-400 text-sm">
                      {track.description}
                    </p>
                  </div>

                  {isSelected && (
                    <div className="flex items-center gap-2 text-purple-400 text-sm">
                      <div className="w-5 h-5 rounded-full bg-purple-500 flex items-center justify-center">
                        <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                      Selected
                    </div>
                  )}
                </div>
              </Card>
            );
          })}
        </div>

        {/* Continue Button */}
        <div className="flex justify-center">
          <Button
            size="lg"
            className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 px-12"
            disabled={!selectedTrack}
            onClick={handleContinue}
          >
            Continue to Assessment
          </Button>
        </div>
      </div>
    </div>
  );
}
