import { useNavigate } from 'react-router-dom';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Brain, TrendingUp, TrendingDown, Award, ArrowRight } from 'lucide-react';

const skillScores = [
  { name: 'Logic & Problem Solving', score: 85, color: 'bg-green-500' },
  { name: 'Programming Basics', score: 78, color: 'bg-blue-500' },
  { name: 'Framework Knowledge', score: 65, color: 'bg-yellow-500' },
  { name: 'Algorithm Design', score: 72, color: 'bg-purple-500' },
  { name: 'System Design', score: 58, color: 'bg-orange-500' },
  { name: 'Best Practices', score: 81, color: 'bg-teal-500' }
];

const strengths = [
  'Strong foundation in problem-solving and algorithmic thinking',
  'Good understanding of programming fundamentals',
  'Excellent grasp of coding best practices and clean code principles'
];

const improvements = [
  'System design patterns and architecture principles',
  'Advanced framework features and optimization techniques',
  'Database design and query optimization'
];

export default function EvaluationFeedback() {
  const navigate = useNavigate();
  const overallScore = Math.round(skillScores.reduce((acc, curr) => acc + curr.score, 0) / skillScores.length);

  const getLevel = (score: number) => {
    if (score >= 80) return { label: 'Advanced', color: 'bg-green-500' };
    if (score >= 60) return { label: 'Intermediate', color: 'bg-blue-500' };
    return { label: 'Beginner', color: 'bg-yellow-500' };
  };

  const level = getLevel(overallScore);

  return (
    <div className="min-h-screen bg-[#0d0d0d] p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center">
              <Brain className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-white text-2xl">Assessment Results</h1>
          </div>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Here's your personalized evaluation based on your assessment
          </p>
        </div>

        {/* Overall Score Card */}
        <Card className="bg-gradient-to-br from-purple-900/20 to-blue-900/20 border-purple-500/30 p-8 mb-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-6">
              <div className="w-24 h-24 rounded-full bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center">
                <Award className="w-12 h-12 text-white" />
              </div>
              <div>
                <h2 className="text-white mb-2">Your Current Level</h2>
                <Badge className={`${level.color} text-white px-4 py-1 text-lg`}>
                  {level.label}
                </Badge>
              </div>
            </div>
            <div className="text-center">
              <div className="text-6xl mb-2 bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
                {overallScore}
              </div>
              <p className="text-gray-400">Overall Score</p>
            </div>
          </div>
        </Card>

        {/* Skill Breakdown */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          <Card className="bg-[#1a1a1a] border-gray-800 p-6">
            <h3 className="text-white mb-6 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-purple-400" />
              Skill Breakdown
            </h3>
            <div className="space-y-5">
              {skillScores.map((skill, index) => (
                <div key={index} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300 text-sm">{skill.name}</span>
                    <span className="text-white">{skill.score}%</span>
                  </div>
                  <div className="relative h-2 bg-gray-800 rounded-full overflow-hidden">
                    <div
                      className={`absolute left-0 top-0 h-full ${skill.color} rounded-full transition-all duration-500`}
                      style={{ width: `${skill.score}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <div className="space-y-6">
            {/* Strengths */}
            <Card className="bg-[#1a1a1a] border-gray-800 p-6">
              <h3 className="text-white mb-4 flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-green-400" />
                Your Strengths
              </h3>
              <ul className="space-y-3">
                {strengths.map((strength, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <div className="w-1.5 h-1.5 rounded-full bg-green-500 mt-2 flex-shrink-0" />
                    <span className="text-gray-300 text-sm">{strength}</span>
                  </li>
                ))}
              </ul>
            </Card>

            {/* Areas for Improvement */}
            <Card className="bg-[#1a1a1a] border-gray-800 p-6">
              <h3 className="text-white mb-4 flex items-center gap-2">
                <TrendingDown className="w-5 h-5 text-orange-400" />
                Areas for Improvement
              </h3>
              <ul className="space-y-3">
                {improvements.map((improvement, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <div className="w-1.5 h-1.5 rounded-full bg-orange-500 mt-2 flex-shrink-0" />
                    <span className="text-gray-300 text-sm">{improvement}</span>
                  </li>
                ))}
              </ul>
            </Card>
          </div>
        </div>

        {/* Call to Action */}
        <Card className="bg-gradient-to-r from-purple-900/20 to-blue-900/20 border-purple-500/30 p-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <h3 className="text-white mb-2">Ready to Start Learning?</h3>
              <p className="text-gray-400">
                We've generated a personalized roadmap based on your assessment
              </p>
            </div>
            <Button
              size="lg"
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
              onClick={() => navigate('/roadmap')}
            >
              View Your Roadmap
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
}
