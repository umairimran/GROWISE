import { useNavigate } from 'react-router-dom';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Brain, TrendingUp, Clock, Award, Target, Calendar, Flame, ArrowRight } from 'lucide-react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';

const weeklyProgress = [
  { day: 'Mon', hours: 2.5 },
  { day: 'Tue', hours: 3.2 },
  { day: 'Wed', hours: 1.8 },
  { day: 'Thu', hours: 4.1 },
  { day: 'Fri', hours: 2.7 },
  { day: 'Sat', hours: 5.3 },
  { day: 'Sun', hours: 3.9 }
];

const skillTrends = [
  { month: 'Sep', score: 45 },
  { month: 'Oct', score: 58 },
  { month: 'Nov', score: 67 },
  { month: 'Dec', score: 73 },
  { month: 'Jan', score: 78 }
];

const skillRadar = [
  { skill: 'Problem Solving', score: 85 },
  { skill: 'Coding', score: 78 },
  { skill: 'Design', score: 65 },
  { skill: 'Testing', score: 72 },
  { skill: 'Architecture', score: 58 }
];

const badges = [
  { name: 'First Steps', icon: '🎯', earned: true },
  { name: 'Week Warrior', icon: '⚔️', earned: true },
  { name: 'Code Master', icon: '💻', earned: true },
  { name: 'Problem Solver', icon: '🧩', earned: false },
  { name: 'Speed Demon', icon: '⚡', earned: false },
  { name: 'Consistency King', icon: '👑', earned: false }
];

const nextRecommendations = [
  {
    title: 'Advanced React Patterns',
    reason: 'Based on your progress in React fundamentals',
    duration: '3 weeks'
  },
  {
    title: 'System Design Basics',
    reason: 'To strengthen your architecture skills',
    duration: '4 weeks'
  },
  {
    title: 'Testing with Jest',
    reason: 'Improve your testing capabilities',
    duration: '2 weeks'
  }
];

export default function UserInsights() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-[#0d0d0d] p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-12">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <h1 className="text-white text-2xl">Your Learning Insights</h1>
            </div>
            <p className="text-gray-400">Track your progress and discover growth opportunities</p>
          </div>
          <Button
            variant="outline"
            onClick={() => navigate('/roadmap')}
            className="bg-[#1a1a1a] border-gray-800 hover:bg-[#252525] text-white"
          >
            View Roadmap
          </Button>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-purple-900/20 to-purple-950/40 border-purple-500/30 p-6">
            <div className="flex items-center justify-between mb-2">
              <Clock className="w-8 h-8 text-purple-400" />
              <Badge className="bg-purple-600/20 text-purple-400">This Week</Badge>
            </div>
            <div className="text-3xl text-white mb-1">23.5h</div>
            <p className="text-sm text-gray-400">Learning Time</p>
          </Card>

          <Card className="bg-gradient-to-br from-green-900/20 to-green-950/40 border-green-500/30 p-6">
            <div className="flex items-center justify-between mb-2">
              <Target className="w-8 h-8 text-green-400" />
              <Badge className="bg-green-600/20 text-green-400">+12%</Badge>
            </div>
            <div className="text-3xl text-white mb-1">8</div>
            <p className="text-sm text-gray-400">Modules Completed</p>
          </Card>

          <Card className="bg-gradient-to-br from-orange-900/20 to-orange-950/40 border-orange-500/30 p-6">
            <div className="flex items-center justify-between mb-2">
              <Flame className="w-8 h-8 text-orange-400" />
              <Badge className="bg-orange-600/20 text-orange-400">Record!</Badge>
            </div>
            <div className="text-3xl text-white mb-1">15</div>
            <p className="text-sm text-gray-400">Day Streak</p>
          </Card>

          <Card className="bg-gradient-to-br from-blue-900/20 to-blue-950/40 border-blue-500/30 p-6">
            <div className="flex items-center justify-between mb-2">
              <Award className="w-8 h-8 text-blue-400" />
              <Badge className="bg-blue-600/20 text-blue-400">Top 10%</Badge>
            </div>
            <div className="text-3xl text-white mb-1">78</div>
            <p className="text-sm text-gray-400">Overall Score</p>
          </Card>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          <Card className="bg-[#1a1a1a] border-gray-800 p-6">
            <div className="flex items-center gap-2 mb-6">
              <TrendingUp className="w-5 h-5 text-purple-400" />
              <h3 className="text-white">Weekly Activity</h3>
            </div>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={weeklyProgress}>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                <XAxis dataKey="day" stroke="#666" />
                <YAxis stroke="#666" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1a1a1a',
                    border: '1px solid #333',
                    borderRadius: '8px',
                    color: '#fff'
                  }}
                />
                <Bar dataKey="hours" fill="url(#colorGradient)" radius={[8, 8, 0, 0]} />
                <defs>
                  <linearGradient id="colorGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#a855f7" />
                    <stop offset="100%" stopColor="#3b82f6" />
                  </linearGradient>
                </defs>
              </BarChart>
            </ResponsiveContainer>
          </Card>

          <Card className="bg-[#1a1a1a] border-gray-800 p-6">
            <div className="flex items-center gap-2 mb-6">
              <Calendar className="w-5 h-5 text-blue-400" />
              <h3 className="text-white">Skill Growth Trend</h3>
            </div>
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={skillTrends}>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                <XAxis dataKey="month" stroke="#666" />
                <YAxis stroke="#666" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1a1a1a',
                    border: '1px solid #333',
                    borderRadius: '8px',
                    color: '#fff'
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="score"
                  stroke="#3b82f6"
                  strokeWidth={3}
                  dot={{ fill: '#3b82f6', r: 5 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </Card>
        </div>

        {/* Skill Radar and Badges */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          <Card className="bg-[#1a1a1a] border-gray-800 p-6">
            <h3 className="text-white mb-6">Skill Distribution</h3>
            <ResponsiveContainer width="100%" height={300}>
              <RadarChart data={skillRadar}>
                <PolarGrid stroke="#333" />
                <PolarAngleAxis dataKey="skill" stroke="#999" />
                <PolarRadiusAxis stroke="#666" />
                <Radar
                  name="Skills"
                  dataKey="score"
                  stroke="#a855f7"
                  fill="#a855f7"
                  fillOpacity={0.3}
                />
              </RadarChart>
            </ResponsiveContainer>
          </Card>

          <Card className="bg-[#1a1a1a] border-gray-800 p-6">
            <h3 className="text-white mb-6">Badges Earned</h3>
            <div className="grid grid-cols-3 gap-4">
              {badges.map((badge, index) => (
                <div
                  key={index}
                  className={`flex flex-col items-center gap-2 p-4 rounded-lg border ${
                    badge.earned
                      ? 'bg-gradient-to-br from-purple-900/20 to-blue-900/20 border-purple-500/30'
                      : 'bg-gray-900/20 border-gray-800'
                  }`}
                >
                  <div className={`text-3xl ${!badge.earned && 'grayscale opacity-40'}`}>
                    {badge.icon}
                  </div>
                  <span className={`text-xs text-center ${badge.earned ? 'text-gray-300' : 'text-gray-600'}`}>
                    {badge.name}
                  </span>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Recommendations */}
        <Card className="bg-[#1a1a1a] border-gray-800 p-6">
          <h3 className="text-white mb-6">Recommended Next Steps</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {nextRecommendations.map((rec, index) => (
              <Card
                key={index}
                className="bg-[#0d0d0d] border-gray-800 p-5 hover:border-purple-500/50 transition-all cursor-pointer group"
              >
                <h4 className="text-white mb-2 group-hover:text-purple-400 transition-colors">
                  {rec.title}
                </h4>
                <p className="text-gray-400 text-sm mb-3">{rec.reason}</p>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-500">⏱️ {rec.duration}</span>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="text-purple-400 hover:text-purple-300 p-0"
                    onClick={() => navigate('/roadmap')}
                  >
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </Card>

        {/* CTA */}
        <Card className="bg-gradient-to-r from-purple-900/20 to-blue-900/20 border-purple-500/30 p-8 mt-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <h3 className="text-white mb-2">Ready for the Final Evaluation?</h3>
              <p className="text-gray-400">
                Test your skills with an AI-powered technical interview simulation
              </p>
            </div>
            <Button
              size="lg"
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
              onClick={() => navigate('/ai-evaluation')}
            >
              Start AI Evaluation
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
}
